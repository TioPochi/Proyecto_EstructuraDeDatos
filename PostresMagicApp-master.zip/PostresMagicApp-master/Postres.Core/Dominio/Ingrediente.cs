﻿
using System.Collections.Generic;

namespace Postres.Core.Dominio
{
    public class Ingrediente
    {
        public string Id { get; set; }
        public string Nombre { get; set; }
        public int Cantidad { get; set; } 
    }
}
